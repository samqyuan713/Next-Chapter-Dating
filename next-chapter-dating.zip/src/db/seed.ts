import { db } from "./index.ts";
import { users, activityGroups } from "./schema.ts";
import { eq } from "drizzle-orm";

export async function seedDatabase() {
  try {
    // 1. Check if users are already seeded
    const existingUsers = await db.select().from(users).limit(1);
    if (existingUsers.length > 0) {
      console.log("Database already seeded with default profiles. Skipping user seeding.");
    } else {
      console.log("Seeding authentic companion profiles to Cloud SQL...");
      
      const seedProfiles = [
        {
          uid: "profile-1",
          email: "sarah.lin@matchmaking.net",
          name: "Sarah Lin (林敏梅)",
          age: 47,
          gender: "female",
          location: "Seattle, WA (Vancouver-raised)",
          occupation: "Bonsai Garden Curator & Ikebana Teacher",
          avatar: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&q=80&w=400&h=400",
          tagline: "Cultivating silent beauty and family harmony in the second half of life.",
          relationshipStatus: "Divorced",
          childrenStatus: "Two daughters (one in nursing, one with family)",
          aboutMe: "I help people find quietness in their hearts by building serene miniature bonsai gardens and practicing the art of Ikebana. Having rebuilt my life with respect post-divorce six years ago, I treasure standard routines, morning walks through botanical pathways, and a cup of warm premium Tieguanyin oolong.",
          previousChapterInsight: "My earlier chapters taught me that keeping up appearances and family face to please others must never come at the cost of genuine emotional peace. Today, I value a companion who respects quiet boundaries and understands quiet mutual support.",
          whatImLookingFor: "A refined, humble partner who values family filial ties, quiet conversations over hot tea, and a restful co-existence without the pressure of fast dating rules.",
          values: ["Filial Respect", "Quiet Harmony", "Discretion", "Patience", "Sincerity"],
          interests: ["Bonsai Art", "Flower arrangement", "Oolong tea", "Acoustic Qin music", "Morning Tai Chi"],
          icebreakerQuestion: "My definition of a perfect, quiet weekend is...",
          icebreakerAnswer: "A quiet morning watering the balcony orchids, tracing ink calligraphy strokes with soft classical music, and sharing a simple, nutritious double-boiled soup.",
          height: "162 cm",
          weight: "53 kg",
          education: "Master of Fine Arts (University of British Columbia)",
          ancestralRoots: "Fujian (Minnan) ancestry, raised in Vancouver",
          chineseZodiac: "Year of the Goat (🐑)",
          personalHobbies: ["Nurturing delicate white orchids", "Practicing traditional cursive calligraphy", "Gourmet soup culinary arts", "Attending acoustic harp & Qin concerts"],
          preferredPartnerAge: "45 - 58",
          preferredPartnerHeight: "170 cm +",
          preferredPartnerEducation: "Master's or equivalent post-secondary standard",
          preferredPartnerRoots: "Southern Chinese heritage (Minnan/Chaoshan) preferred",
          preferredPartnerDescription: "A gentleman who values stable daily rhythms, holds a deep respect for elders, speaks with gentle volume, and appreciates high-grade Oolong tea.",
          sportsActivities: ["Morning flow Tai Chi (太极拳)", "Rhythmic deep breathing guidelines", "Slow-paced botanical trail walking"],
          socialPreferences: "Greatly prefers intimate, small-circle traditional tea sessions and quiet family dinners; avoids high-density noisy public parties.",
          photos: [
            "https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&q=80&w=600&h=600",
            "https://images.unsplash.com/photo-1576092768241-dec231879fc3?auto=format&fit=crop&q=80&w=600&h=600",
            "https://images.unsplash.com/photo-1512428559087-560fa5ceab42?auto=format&fit=crop&q=80&w=600&h=600",
            "https://images.unsplash.com/photo-1506084868230-bb9d95c24759?auto=format&fit=crop&q=80&w=600&h=600"
          ]
        },
        {
          uid: "profile-2",
          email: "raymond.goh@matchmaking.net",
          name: "Dr. Raymond Goh (吴国荣)",
          age: 53,
          gender: "male",
          location: "Bay Area, CA (Singapore-born)",
          occupation: "Traditional Herbal Medicine Scholar & Orchid Hybridist",
          avatar: "https://images.unsplash.com/photo-1537368910025-700350fe46c7?auto=format&fit=crop&q=80&w=400&h=400",
          tagline: "Nurturing physical wellness and heart stability with patience.",
          relationshipStatus: "Widowed",
          childrenStatus: "One adult son (respectfully settled)",
          aboutMe: "I spend my days studying medicinal herbs and volunteering at structural community centers. Since losing my wife five years ago, I have learned the true comfort of slowness. I find solace in restoring raw block furniture, brewing premium Pu-erh tea, and weekend strolls near tranquil lakes.",
          previousChapterInsight: "Durable relationships are like slow-growing bamboo—they require quiet soil, roots grounded in mutual respect, and regular attention. I believe we can start a peaceful, respectful second chapter with quiet courage.",
          whatImLookingFor: "A warm, soft-spoken companion to share tea sessions, talk about family history, and enjoy steady weekend strolls through quiet temple pathways.",
          values: ["Family devotion", "Generosity", "Humility", "Physical wellness", "Patience"],
          interests: ["Herbal tea brewing", "Chinese Calligraphy", "Classical bamboo flute", "Tranquil hikes", "Antique coin collecting"],
          icebreakerQuestion: "A small wellness ritual I treasure daily...",
          icebreakerAnswer: "Waking up before dawn to enjoy hot ginger-infused red date tea, listening to the birds, and doing deep breathing exercises near open windows.",
          height: "175 cm",
          weight: "71 kg",
          education: "Ph.D. in Botanical Science & Chinese Herbal Remedies (NUS)",
          ancestralRoots: "Guangdong (Teochew-Hakka) ancestry",
          chineseZodiac: "Year of the Ox (🐂)",
          personalHobbies: ["Hybridizing rare orchid varieties", "Collecting historic bronze tea kettles", "Restoring antique Mahogany cabinets", "Hiking historic paths"],
          preferredPartnerAge: "45 - 55",
          preferredPartnerHeight: "158 cm - 170 cm",
          preferredPartnerEducation: "College graduate or higher",
          preferredPartnerRoots: "Guangdong, Hong Kong, or Southeast Asian diaspora",
          preferredPartnerDescription: "A refined, soft-spoken lady who conducts herself with quiet poise, values traditional family rituals, has a warm heart, and maintains wellness.",
          sportsActivities: ["Therapeutic Qigong (气功)", "Gentle scenic golf", "Morning warm lake walking tracks"],
          socialPreferences: "Prefers quiet heritage society circles, local botanical tours, and cozy herbal cooking workshops. Highly values respect and soft volume speaking.",
          photos: [
            "https://images.unsplash.com/photo-1537368910025-700350fe46c7?auto=format&fit=crop&q=80&w=600&h=600",
            "https://images.unsplash.com/photo-1563245372-f21724e3856d?auto=format&fit=crop&q=80&w=600&h=600",
            "https://images.unsplash.com/photo-1530026405186-ed1ea0ac7a63?auto=format&fit=crop&q=80&w=600&h=600"
          ]
        },
        {
          uid: "profile-3",
          email: "meilin.tan@matchmaking.net",
          name: "Meilin Tan (陈美玲)",
          age: 51,
          gender: "female",
          location: "Richmond, BC (Taipei-born)",
          occupation: "Retired Guzheng Musician & Tea Room Host",
          avatar: "https://images.unsplash.com/photo-1508214751196-bcfd4ca60f91?auto=format&fit=crop&q=80&w=400&h=400",
          tagline: "Weaving string melodies and traditional tea ritual into a restful sanctuary.",
          relationshipStatus: "Divorced",
          childrenStatus: "Grateful mother, adult children live nearby",
          aboutMe: "Spent 25 years teaching classical Guzheng string instruments. Today, I host traditional, low-pressure tea appreciation gather-circles. I appreciate quiet watercolors, cooking restorative family soups, and the soft warmth of afternoon incense.",
          previousChapterInsight: "Divorce taught me that silent emotional safety is far more valuable than standard superficial validation. No excess drama, only steady emotional support and deep, mutual respect.",
          whatImLookingFor: "A companion with a gentle demeanor, someone who appreciates stable family schedules, enjoys traditional meals, and values a calm second chapter.",
          values: ["Gentleness", "Quiet Dignity", "Filial Piety", "Family warmth", "Mutual respect"],
          interests: ["Guzheng classical strings", "Ink watercolor painting", "Healthy traditional cooking", "Garden design", "Classic poetry readings"],
          icebreakerQuestion: "The custom that links me closest to my ancestry...",
          icebreakerAnswer: "Hosting tea ceremonies for my close friends, focusing on the sensory sounds of bubbling stream-water and slow-roasted tea leaves.",
          height: "160 cm",
          weight: "51 kg",
          education: "Bachelor of Traditional Music (Taipei National University of the Arts)",
          ancestralRoots: "Zhejiang (Ningbo) ancestry, born in Taipei",
          chineseZodiac: "Year of the Pig (🐖)",
          personalHobbies: ["Playing ancient Guzheng string solos", "Ink-wash landscape watercolor", "Slow double-boiling Cantonese bone broths", "Visiting botanical glasshouses"],
          preferredPartnerAge: "49 - 63",
          preferredPartnerHeight: "172 cm +",
          preferredPartnerEducation: "Bachelor's standard, professional background preferred",
          preferredPartnerRoots: "Zhejiang, Shanghai, or Taiwan heritage raises interest",
          preferredPartnerDescription: "An educated, well-mannered gentleman of good moral character, who enjoys fine music, does not smoke, and values dedicated filial duties.",
          sportsActivities: ["Gentle pool water exercises", "Slow posture alignment yoga", "Calm temple park strolling"],
          socialPreferences: "Relishes serene, small traditional poetry clubs and classical musical recitals; is uncomfortable with modern speed-networking or casual lounges.",
          photos: [
            "https://images.unsplash.com/photo-1508214751196-bcfd4ca60f91?auto=format&fit=crop&q=80&w=600&h=600",
            "https://images.unsplash.com/photo-1515233599490-e51f16276b24?auto=format&fit=crop&q=80&w=600&h=600",
            "https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?auto=format&fit=crop&q=80&w=600&h=600"
          ]
        },
        {
          uid: "profile-4",
          email: "junho.park@matchmaking.net",
          name: "Master Jun-Ho Park (朴俊浩)",
          age: 58,
          gender: "male",
          location: "Los Angeles, CA (Seoul-raised)",
          occupation: "Traditional Hand-crafted Teaware Artisan",
          avatar: "https://images.unsplash.com/photo-1542909168-82c3e7fdca5c?auto=format&fit=crop&q=80&w=400&h=400",
          tagline: "Shaping simple wood and clay, seeking a restful soul mate for steady twilight years.",
          relationshipStatus: "Single Parent",
          childrenStatus: "Caring for aging father and supporting university son",
          aboutMe: "I craft fine clay teapots and hand-carved wooden trays. My life is defined by service—providing cozy stability for my aging father and helping my son finish his studies. I seek simplicity, traditional moral alignments, and a peaceful heart.",
          previousChapterInsight: "Caring for a multi-generational family has taught me that real love is expressed through quiet acts of service, uncomplaining dedication, and soft patience. I respect partners who hold similar family standards.",
          whatImLookingFor: "A mature partner who values filial responsibilities, understands that family tasks always come first, and shares a passion for slow living.",
          values: ["Filial commitment", "Refined simplicity", "Humbler attitudes", "Steadfast loyalty", "Kindness"],
          interests: ["Clay pottery sculpting", "Wood block carving", "Korean Zen traditions", "Herbal soups", "Mountain walking trails"],
          icebreakerQuestion: "My favorite way to spend a quiet evening...",
          icebreakerAnswer: "Serving my elderly father a bowl of warm broth, followed by resting on the patio with a cup of green barley tea under the stars.",
          height: "178 cm",
          weight: "76 kg",
          education: "B.Sc. in Ceramic Engineering (Seoul National University)",
          ancestralRoots: "Gyeonggi Province roots, Seoul-raised",
          chineseZodiac: "Year of the Monkey (🐒)",
          personalHobbies: ["Hand-spinning clay teaware in studio", "Carving patterns on oak & walnut wood blocks", "Deep breathing meditation in the garden", "Studying Korean traditional ceramic glazes"],
          preferredPartnerAge: "50 - 60",
          preferredPartnerHeight: "158 cm - 168 cm",
          preferredPartnerEducation: "University degree preferred",
          preferredPartnerRoots: "Korean or East Asian family background",
          preferredPartnerDescription: "A filial, practical woman who acts with deep family responsibility and understanding, appreciates rustic art, and has a gentle and supportive nature.",
          sportsActivities: ["Traditional wooden sword forms (Kumdo)", "Morning stretching & alignment", "Moderate mountain trail hiking"],
          socialPreferences: "Holds a profound preference for small heritage associations, traditional master craftsman workshops, and close-knit family reunions.",
          photos: [
            "https://images.unsplash.com/photo-1542909168-82c3e7fdca5c?auto=format&fit=crop&q=80&w=600&h=600",
            "https://images.unsplash.com/photo-1618220179428-22790b461013?auto=format&fit=crop&q=80&w=600&h=600",
            "https://images.unsplash.com/photo-1447078826665-1545b46e5a61?auto=format&fit=crop&q=80&w=600&h=600"
          ]
        },
        {
          uid: "profile-5",
          email: "sunita.nair@matchmaking.net",
          name: "Sunita Nair (孙妮达)",
          age: 46,
          gender: "female",
          location: "Seattle, WA (Singapore-raised)",
          occupation: "Ayurvedic Herb Specialist & Heritage Pastry Chef",
          avatar: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&q=80&w=400&h=400",
          tagline: "Merging traditional herbal wisdom and slow sweet pastries for comfort.",
          relationshipStatus: "Starting Over",
          childrenStatus: "No children, dedicated to school-community and family",
          aboutMe: "I research herbal properties and formulate natural herbal wellness balances. After spending my early years career-focused, my previous paths taught me to embrace slow living. I spend weekends sketching in temple botanical greenhouses, baking traditional cardamom treats, and reading philosophy.",
          previousChapterInsight: "I used to think relationship success meant absolute perfection and career heights. Now, I understand that steady reliability, quiet listening, and mutual family respect are the absolute ultimate luxury.",
          whatImLookingFor: "A companion of gentle strength, who is eager to co-create a peaceful, slow household and support standard filial routines.",
          values: ["Intellectual serenity", "Generosity", "Humbler perspective", "Family appreciation", "Emotional safety"],
          interests: ["Ayurvedic herbs", "Traditional baking", "Greenhouse botanical painting", "Traditional temple paths", "Ethical volunteering"],
          icebreakerQuestion: "The philosophy that inspires my slow mornings...",
          icebreakerAnswer: "The concept of \"Shanti\" or inner peace. Taking time to sit in complete silence for fifteen minutes before the world wakes up is the anchor of my day.",
          height: "165 cm",
          weight: "58 kg",
          education: "Master of Science in Ethnobotany & Heritage Agronomy",
          ancestralRoots: "Kerala heritage, born and raised in Singapore",
          chineseZodiac: "Year of the Dragon (🐉)",
          personalHobbies: ["Formulating heritage cardamom wellness cookies", "Pencil sketching of high-alpine wildflowers", "Reading Vedic and stoic philosophy", "Volunteering with low-income senior citizens"],
          preferredPartnerAge: "44 - 54",
          preferredPartnerHeight: "170 cm - 185 cm",
          preferredPartnerEducation: "Postgraduate preferred (Ph.D, MD, MS, or MBA)",
          preferredPartnerRoots: "Open-minded or Southeast Asian/Indian heritage",
          preferredPartnerDescription: "A kind-hearted, intellectually curious man of action, who respects healthy lifestyles, treats everyone with dignity, and values warm gatherings.",
          sportsActivities: ["Pranayama breath control", "Restorative Kundalini yoga", "Daily brisk natural trail walks"],
          socialPreferences: "Enjoys intimate community volunteering circles, mindful study seminars, and private dining rooms; prefers deep sharing over superficial large chit-chats.",
          photos: [
            "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&q=80&w=600&h=600",
            "https://images.unsplash.com/photo-1545205597-3d9d02c29597?auto=format&fit=crop&q=80&w=600&h=600",
            "https://images.unsplash.com/photo-1506126613408-eca07ce68773?auto=format&fit=crop&q=80&w=600&h=600"
          ]
        },
        {
          uid: "profile-6",
          email: "william.wu@matchmaking.net",
          name: "William Wu (吴建德)",
          age: 62,
          gender: "male",
          location: "Seattle, WA (Hong Kong-born)",
          occupation: "Retired High School Principal & Calligraphy Society Guide",
          avatar: "https://images.unsplash.com/photo-1492562080023-ab3db95bfbce?auto=format&fit=crop&q=80&w=400&h=400",
          tagline: "Tracing steady ink brush strokes, seeking companionship for life’s second volume.",
          relationshipStatus: "Widowed",
          childrenStatus: "Adult children, respectfully settled in Seattle and Singapore",
          aboutMe: "I served as a school administrator for 30 years. Now retired, I spend warm afternoons teaching calligraphy to youth societies and practicing brush writing. I value traditional diligence, family honor, photography walks, and light tea discussions.",
          previousChapterInsight: "Losing my late wife after 35 years of marriage taught me that love calls for daily humbleness and service. We do not set out to replace the beautiful memories, but to cultivate a calm, comforting second journey with immense respect.",
          whatImLookingFor: "An elegant, self-reliant woman who appreciates peaceful humor, traditional values, filial family visits, and slow scenic drives.",
          values: ["Patience", "Quiet dignity", "Traditional diligence", "Integrity", "Discretion"],
          interests: ["Ink Calligraphy", "Classical landscape photography", "Pu-erh tea aging", "Chinese lute", "Temple historical research"],
          icebreakerQuestion: "The spot where I find the ultimate tranquility...",
          icebreakerAnswer: "My writing desk, where the scent of black pine-soot ink and sound of paper absorbing moisture creates a silent, beautiful bridge to the ancestors.",
          height: "172 cm",
          weight: "69 kg",
          education: "Master of Educational Administration (The Chinese University of Hong Kong)",
          ancestralRoots: "Guangdong (Panyu) roots, born in Hong Kong",
          chineseZodiac: "Year of the Tiger (🐯)",
          personalHobbies: ["Writing historical calligraphy sheets", "Aging raw Pu-erh tea bricks", "Playing meditative Guqin melodies", "Documenting Buddhist temple architecture"],
          preferredPartnerAge: "52 - 62",
          preferredPartnerHeight: "155 cm - 168 cm",
          preferredPartnerEducation: "College graduate or above",
          preferredPartnerRoots: "Guangdong, Chao Feng, or Hong Kong lineage appreciated",
          preferredPartnerDescription: "An elegant, self-reliant woman who holds family values dear, loves arts or literature, speaks nicely, and desires a peaceful, cooperative second journey.",
          sportsActivities: ["Daily calligraphy arm posture training", "Reflective long garden strolls", "Breathing coordination training"],
          socialPreferences: "Enjoys academic and historical society guilds, guide sessions, and intimate family dinners. Avoids loud commercial venues.",
          photos: [
            "https://images.unsplash.com/photo-1492562080023-ab3db95bfbce?auto=format&fit=crop&q=80&w=600&h=600",
            "https://images.unsplash.com/photo-1557804506-669a67965ba0?auto=format&fit=crop&q=80&w=600&h=600",
            "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&q=80&w=600&h=600"
          ]
        }
      ];

      for (const p of seedProfiles) {
        await db.insert(users).values(p).onConflictDoNothing();
      }
      console.log("Successfully seeded users.");
    }

    // 2. Seed activity groups
    const existingGroups = await db.select().from(activityGroups).limit(1);
    if (existingGroups.length > 0) {
      console.log("Database already seeded with Cafe Rooms. Skipping group seeding.");
    } else {
      console.log("Seeding Cafe Rooms to Cloud SQL...");
      const seedRooms = [
        {
          title: "🍵 Morning Puerh & Quiet Chats",
          description: "A quiet, low-pressure board for tea lovers to exchange tips on aging Pu-erh and Tieguanyin, and arrange relaxed walks to local tea rooms.",
          participantsCount: 42,
          tags: ["Tea appreciation", "Calm living", "Tealife"],
          hostName: "Sarah Lin (林敏梅)"
        },
        {
          title: "🤝 Filial Care & Family Harmony Circles",
          description: "A compassionate support circle for middle-aged children who balance career, personal life, and caring for elderly parents with honor and respect.",
          participantsCount: 68,
          tags: ["Parent support", "Family harmony", "Filial duty"],
          hostName: "Dr. Raymond Goh (吴国荣)"
        },
        {
          title: "✍️ Calligraphy & Ink Brush Serenity",
          description: "For scholars and beginners who love the focus of Calligraphy, brush painting, and poetry, seeking a quiet space of concentration.",
          participantsCount: 25,
          tags: ["Calligraphy", "Traditional Art", "Quiet Focus"],
          hostName: "William Wu (吴建德)"
        },
        {
          title: "🚶 Hidden Temple & Conservatory Walks",
          description: "For mid-life neighbors who love tranquil, slow-paced walks through greenhouses, botanical reserves, and historical temple gardens.",
          participantsCount: 31,
          tags: ["Tranquil strolls", "Nature reserves", "Quiet walkers"],
          hostName: "Sunita Nair (孙妮达)"
        }
      ];

      for (const r of seedRooms) {
        await db.insert(activityGroups).values(r);
      }
      console.log("Successfully seeded activity groups.");
    }
  } catch (error) {
    console.error("Failed to seed Cloud SQL database:", error);
  }
}
